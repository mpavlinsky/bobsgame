These files are part of the AntTweakBar library.
http://www.antisphere.com/Wiki/tools:anttweakbar

AntTweakBar is a free software released under the zlib license.
For conditions of distribution and use, see ../License.txt

To rebuild the library on Windows, use the VS2008 solution in the src directory.

To build the library on Linux, open a terminal, go in the src directory and
type make

To build the library on MacOSX, open a terminal, go in the src directory and
type make -f Makefile.osx

