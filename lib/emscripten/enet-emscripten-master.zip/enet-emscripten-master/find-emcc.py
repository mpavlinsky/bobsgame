#!/usr/bin/python
import os
execfile(os.path.expanduser("~/.emscripten"))
print EMSCRIPTEN_ROOT

