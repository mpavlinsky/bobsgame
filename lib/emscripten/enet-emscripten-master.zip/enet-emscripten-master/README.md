## enet-emscripten

This is a workspace/demo for building the ENet networking library using emscripten.

to build the code:

    make build 

to run the tests:

    node test client server


