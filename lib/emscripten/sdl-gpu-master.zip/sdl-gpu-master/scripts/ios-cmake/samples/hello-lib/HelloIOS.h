#import <UIKit/UIKit.h>

@interface HelloIOS:UIViewController

- (NSString*)getHello;

@end
