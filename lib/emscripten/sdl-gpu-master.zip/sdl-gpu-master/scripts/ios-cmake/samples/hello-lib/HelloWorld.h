#ifndef HELLOWORLD_H
#define HELLOWORLD_H

#include <string>
using namespace std;

class HelloWorld{
public:
	string helloWorld();
};

#endif 
