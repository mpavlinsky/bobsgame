This project provides a simple iOS toolchain file that may be used with CMake to build libraries and setup applications. A couple of sample projects are included. 

The iOS toolchain file was developed during the porting of the toadlet engine to iOS platforms. It is also used in that project.

See the included HOWTO.txt file for details.
