//
//  main.m
//  playstream
//
//  Created by Eric Wing on 1/2/13.
//  Copyright (c) 2013 PlayControl Software LLC. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
	return NSApplicationMain(argc, (const char **)argv);
}
