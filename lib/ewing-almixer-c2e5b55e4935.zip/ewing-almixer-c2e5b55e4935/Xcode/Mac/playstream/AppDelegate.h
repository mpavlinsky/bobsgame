//
//  AppDelegate.h
//  playstream
//
//  Created by Eric Wing on 1/2/13.
//  Copyright (c) 2013 PlayControl Software LLC. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>

@property (assign) IBOutlet NSWindow *window;

@end
