//
//  ViewController.h
//  playstream
//
//  Created by Eric Wing on 10/10/12.
//  Copyright (c) 2012 PlayControl Software, LLC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <GLKit/GLKit.h>

@interface ViewController : GLKViewController

@end
