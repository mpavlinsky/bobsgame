#!/bin/sh

# Simple helper script to call clean on ant and CMake

#ant clean
./android/CMakeSupport/make_cmakeandroid.pl --targetdir=build clean

