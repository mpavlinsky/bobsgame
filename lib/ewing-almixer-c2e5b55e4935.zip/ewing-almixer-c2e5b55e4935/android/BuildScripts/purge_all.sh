#!/bin/sh

# Simple helper script to call ant clean and blow away the build directory 
# which also contains CMake generated stuff.

#ant clean
rm -rf build

