These are convenience scripts to help build things. They call the scripts in the CMakeSupport directory with the typical parameters.
All of these scripts are intended to be run from the root directory of this project, not this directory, e.g.
./android/BuildScripts/build_module.sh ../openal-soft
./android/BuildScripts/invoke_make.sh

