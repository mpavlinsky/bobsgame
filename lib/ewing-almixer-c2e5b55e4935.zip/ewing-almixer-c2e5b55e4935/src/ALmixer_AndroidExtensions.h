
/* This is private API. Public API is found in ALmixer_PlatformExtensions. */


#ifndef _ALMIXER_ANDROIDEXTENSIONS_H_
#define _ALMIXER_ANDROIDEXTENSIONS_H_

#ifdef __ANDROID__

extern void ALmixer_Android_Quit(void);

#endif /* #ifdef __ANDROID__ */


#endif /* _ALMIXER_ANDROIDEXTENSIONS_H_ */


