load win32Demo.sln in to visual studio express 2008 
thanks
meiry242@gmail.com