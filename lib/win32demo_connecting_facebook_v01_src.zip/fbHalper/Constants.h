#ifndef CONSTANTS_H
#define CONSTANTS_H
#include <string>
using namespace std;

struct HttpPer 
{
    string key;
    string value;
    HttpPer(string k,string v)
    {
        key = k;
        value = v;
    }
    
};





#endif