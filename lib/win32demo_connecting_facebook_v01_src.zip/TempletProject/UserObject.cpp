#include "UserObject.h"


UserObject::UserObject()
{
	;
}

UserObject::~UserObject()
{
	;
}

