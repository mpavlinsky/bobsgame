#include "Group.h"


Group::Group()
{
	;
}

Group::~Group()
{
	;
}
