#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define IDD_DIALOG1                             100
#define IDC_BUTTON2                             1000
#define IDC_BUTTON1                             1002
#define IDC_EDIT1                               1003
