#!/bin/sh
mkdir -p /usr/local/include/mili
cp mili/*.h /usr/local/include/mili

