In this directory you can find generated glue files
for various environments (python, ruby, cs, d...)
