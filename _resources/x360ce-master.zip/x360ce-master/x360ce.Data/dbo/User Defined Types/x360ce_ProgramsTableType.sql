﻿CREATE TYPE [dbo].[x360ce_ProgramsTableType] AS TABLE (
    [FileName]        NVARCHAR (128) NULL,
    [FileProductName] NVARCHAR (256) NULL);

