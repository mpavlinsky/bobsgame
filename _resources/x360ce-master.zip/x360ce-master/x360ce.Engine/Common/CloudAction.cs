﻿namespace x360ce.Engine
{
	public enum CloudAction
	{
		None = 0,
		Insert = 1,
		Update = 2,
		Select = 3,
		Delete = 4,
	}
}
