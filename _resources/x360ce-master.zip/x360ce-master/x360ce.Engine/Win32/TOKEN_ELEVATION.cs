﻿using System;
using System.Collections.Generic;
using System.Text;

namespace x360ce.Engine.Win32
{
	public struct TOKEN_ELEVATION
	{
		public UInt32 TokenIsElevated;
	}

}
