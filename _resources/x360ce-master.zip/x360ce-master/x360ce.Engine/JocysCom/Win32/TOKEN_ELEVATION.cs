﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JocysCom.ClassLibrary.Win32
{
	public struct TOKEN_ELEVATION
	{
		public UInt32 TokenIsElevated;
	}

}
