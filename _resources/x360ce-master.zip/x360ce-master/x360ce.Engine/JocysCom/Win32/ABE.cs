﻿namespace JocysCom.ClassLibrary.Win32
{
	public enum ABE : uint
	{
		ABE_LEFT = 0,
		ABE_TOP = 1,
		ABE_RIGHT = 2,
		ABE_BOTTOM = 3,
	}
}
