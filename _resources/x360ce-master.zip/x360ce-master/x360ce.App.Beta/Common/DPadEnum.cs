﻿using System;

namespace x360ce.App
{
	public enum DPadEnum
	{
		Up = 0,
		Right = 9000,
		Down = 18000,
		Left = 27000,
	}
}
