﻿namespace SharpDX.XInput
{
    using System;

    public enum DeviceQueryType
    {
        Any,
        Gamepad
    }
}

