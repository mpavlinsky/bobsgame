﻿namespace SharpDX.XInput
{
	public enum ThumbIndex: int
	{
		LeftX = 0,
		LeftY = 1,
		RightX = 2,
		RightY = 3,
	}
}
