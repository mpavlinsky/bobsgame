﻿namespace SharpDX.XInput
{
    using System;

    public enum UserIndex : byte
    {
        Any = 0xff,
        Four = 3,
        One = 0,
        Three = 2,
        Two = 1
    }
}

