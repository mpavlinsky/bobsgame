﻿namespace SharpDX.XInput
{
    using System;

    [Flags]
    public enum CapabilityFlags : short
    {
        None = 0,
        VoiceSupported = 4
    }
}

