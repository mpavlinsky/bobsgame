﻿namespace SharpDX.XInput
{
    using System;

    public enum BatteryLevel : byte
    {
        Empty = 0,
        Full = 3,
        Low = 1,
        Medium = 2
    }
}

