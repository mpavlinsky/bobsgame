﻿namespace SharpDX.XInput
{
    using System;

    public enum DeviceType : byte
    {
        Gamepad = 1
    }
}

