﻿namespace SharpDX.XInput
{
    using System;

    public enum BatteryDeviceType
    {
        Gamepad,
        Headset
    }
}

